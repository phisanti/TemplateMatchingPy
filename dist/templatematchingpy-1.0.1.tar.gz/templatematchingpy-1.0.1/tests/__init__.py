"""Test suite for TemplateMatchingPy."""
